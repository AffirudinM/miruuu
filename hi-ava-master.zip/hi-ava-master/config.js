const config = {
  host: "localhost", // default host
  port: 3000 // default port
};
export default config;
