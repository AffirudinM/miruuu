export default {
  nicknames: ["Ava", "Babe", "Sayang", "Avakuu", "Cintuu"],
  greetings: {
    evening: "Good Evening",
    afternoon: "Good Afternoon",
    day: "Good Day",
    morning: "Good Morning",
    night: "Good Night"
  }
};
